[[King Eadric Lioncrest]]
Captain of the guard, [[Captain Darien]]

There's a library, to which we have access thanks to Niamh arranging with the Captain to deputise us.