https://www.worldanvil.com/w/kirileth-dmstretch/a/aerilon-settlement?preview=true

Major locations:
[[Castle Aerilon]]
[[Silver Star]], temple of Aradin
[[Singing Harp]], inn
[[Enchanter's Emporium]]
[[Ironclaw Smithy]]
[[Marcus' Market]]
[[Rusty Tavern]], where guards gather
[[Golden Goose]], the upmarket inn. Lady Aria is known to host parties here sometimes.
[[Herbalist's Shop]]
[[Leatherworker's Shop]]