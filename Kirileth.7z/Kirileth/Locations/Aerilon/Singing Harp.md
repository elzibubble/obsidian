The inn where we were put up for a while upon first reaching [[Aerilon]] with our band of refugees.

[[Kari the bard]] sometimes plays here.