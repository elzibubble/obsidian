Used to contain the Holy Library of Tomealina, before the first [[Orc raids|orc raid]] burned it down, where [[Bri|Bri]] grew up.

[[Niamh]] frequently played at the tavern here.

[[Ren]] also grew up here, less happily.

[[Dax]] was sent here to cool his heels.


The [[Shadowlands]] are just to the southwest.

A forest containing [[Naiadra of the Hidden Glade]] is to the north.