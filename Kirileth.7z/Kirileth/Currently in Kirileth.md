---
tag: nograph
---
|Player   |Character   |Class   |Pet   |
|---|---|---|---|
|Elzi ♀|Brianna ♀|Wildfire druid|Cordelia ♀|
|Cat ♀|Niamh ♀|Bard|Fieran ♂|
|Shannon ♀|Ren ♀|Sorcerer||
|Justin ♂|Daxillium ♂|Bladesinger|Huxley ♂|
|T0talfail ♀|Sana ♀|Fiendlock||

# Immediate

- [ ] Bag the fullplate
- [ ] Explore the hatch
- [ ] Get wounded + achieve harmony
- [ ] Find the starweaver?


# Ongoing

- [ ] [[Orc raids]]
- [ ] [[Dark Magic for Dummies]]
- [ ] [[Bri's Bad Day]]
- [x] [[Blacksmith supplies]]
- [x] [[Branwell massacre]]
- [ ] [[Starweaver AWOL]]