---
tag: recap
---
Prev: [[E02 The Darkness Beneath]]

Absent: Niamh

The team check out the cemetary, where many of the undead tracks originated. There are a few open graves, a crypt and a small chapel. Ren votes to not go into the graveyard. The team opt to approach the chapel first and find it mostly empty, besides a pillar constructed from bones. The altar is broken in half, with the remnants of a recent campfire next to it. A statue of the Lady of Light is in one corner behind the altar, and the Lady of Darkness in the other. Some black candles have rolled just under the altar.

Bri deconstructs the pillar, saying prayers for the dead, and gathers the bones to bury in the graveyard. Dax stays to watch over her while Sana keeps lookout outside. Ren has climbed a tree and is looking into the yard. Once she's gathered the bones up, Bri asks Dax to help her carry them and they somewhat reluctantly enter the yard, over the warnings from Ren and Sana. As if on cue, a severed arm begins to crawl towards them and a mass of undead flesh bursts from the mound.

Sana takes a shot at the arm with her crossbow. Ren fires off a scorching ray from outside the yard, inflicting some serious damage but the arm still moves. The mass summons a rotting worm before surging forward and smacking Bri, who calls out for Dax in pain. Dax summons a shadowy butterfly wing of a sword, runs forward and slices at the mass, causing it to scream in psychic pain as the weird blade passes through it. Bri takes a whack at the mass with her shillelagh and calls out to Cordelia, who appears in a blast of flame, killing the worm.

Sana summons her own Shadowblade and takes a swing which the mass soaks. Ren blasts the arm again with another 2 scorching rays, leaving a small crater where it used to be. The mass misses her with a claw, and then barely connects with a neck bite. Necrotic energy surges through the connection and Bri falls to the floor, unconscious. Bri fails her first death save.

Dax sees this and his face goes blank as he begins his bladesong, tells the creature of his determination to dismember it and makes a hit. Sana is filled with demonic fury, hits once and misses once. Ren's eyes go black. A tentacle reaches out and drags Bri towards her, as Ren launches a chaos bolt at the mass which goes wide. The mass misses Dax twice, who responds with two hits, big damage.

Bri fails her second death save, uses a player reroll and fails again. Sana gets a crit and calls out to Ren to feed Bri the healing potion on her belt. Finally, Ren does so and saves Bri from a premature death in the nick of time. She is confused, particularly as her own arm drags itself up unbidden and fires three fiery beams at the mass. Her lips move unconsciously as the rays penetrate into the mass, causing it to glow for a second before a conflagration rushes upwards from the torso, consuming the head entirely and indisputably laying it to rest.

Bri stares at her hand as Ren scolds/begs her to get out of the graveyard. Ren tries to pull her out along the ground, but isn't strong enough and she falls over. Bri turns around, crawls over and hugs her. Sana piles on, asking if she's OK. Sana gets up, full of adrenaline, and punches a wall. Ren, still panicking, telepathically asks Dax to help them get out of here. Dax's head is full of a litany, repeating "not again, not again, oh not AGAIN". Sana carries Bri out, who clings to Ren's hand as Ren urges Dax to move and get out with them.

Dax does stand up eventually, leaves the graveyard and finally discovers that Bri is still alive. He rushes over and crushes her and Sana in a hug. Bri tries to speak for a second before bursting into floods of tears. Ren tries to hustle them further towards the cart. Having worked through several stages of grief already, Bri falls asleep in Sana's arms. Ren talks to the horse for comfort. 

Dax congratulates Sana on her work, asks her to watch the others and stealthily goes back towards the graveyard, which Ren misses. He scouts the yard cautiously through Huxley's eyes, tips the bones into the open grave, throws the undead remnants and his cloak in after them, and then drives flaming butterflies in after them, one after another, until very little is left. He kicks some dirt over the ash, spits on the grave and leaves.

Back at the wagon, Sana realises that Bri may be infected with the undead plague and eventually, that Dax is missing. Sana sprints back to the yard to fetch Dax. Returning, Sana assesses Bri's wound, which has some greenish venom around it. She determines that there is no undead plague present, much to her relief.

The team head back towards [[Aerilon]] via Bron's, to pick up Jacob and get back on real roads. Bri wakes up briefly, calls for Dax, and when he answers, she crawls over to snuggle into his side, falling asleep immediately. After about 90 minutes, we find a waystation and decide to spend the night. Ren knocks on the door and they are welcomed in. When Bri wakes up, she seems decidedly drunk - and notably amorous towards Dax.

An elf comes downstairs, that both Dax and Sana recognise from the [[Ironclaw Smithy]]. After some discussion, Bri reluctantly downs a tonic he gives her to combat the venom. He also treats her wound. Finally they get his name - Loramir - and go to rest. Bri slips outside again during the night.

Next: [[E04 Aftermath]]