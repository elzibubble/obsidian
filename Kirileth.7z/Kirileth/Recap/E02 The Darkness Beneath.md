---
tag: recap
---
Prev: [[E01 The Shadowed Hearth]]

Absent: None

With Jacob distraught, the team discuss how to proceed. Bri prepares the dead while Dax builds a pyre (with help from Ren) and Niamh cooks and cleans.

Dax initially suggests taking [[The Branwells|Jacob]] back to [[Aerilon]] immediately, out of concern for him, but the rest feel that preventing further killings takes priority. Sana sparks an idea in him that a nearby neighbour might look after him for a night. Just before the funeral, Sana discusses this plan with Jacob, and gives him her jacket as a token of surety that we will pick him up again. Niamh makes an arch comment about making promises on behalf of the group without discussing it first.

Jacob lights the pyre. As the bodies begin to burn, Bri and Niamh notice Samuel's hand rise briefly in a hint of undead infection, before succumbing to the flames. Niamh's violin falters very briefly and they exchange a quick glance. Fortunately Jacob does not see it. Bri discusses the potential for an explosion of infections with Niamh, if they don't track down the threat. Overhearing this, once Jacob has gone to sleep, Dax pops a firebolt into bodies on the pyre. Just to make sure.

Ren goes to see to Benny aka (Ren) "Shithead" aka (Dax) "Sir Reginald" - our horse who pulls the cart. Dax asks Bri to check on her, to which she readily agrees. Bri tells her off for using foul language and expresses her sadness that they haven't talked in a while, before circuitously confiding in her that she kissed Dax, asking her to keep this a secret. They discuss how each have killed now and how the group seem to be embroiled in violence. Bri makes a couple of weird comments about "predators have to be dealt with" and "can't have people hunting on my territory" which Ren found slightly puzzling but mostly took in stride.

Niamh and Sana feed Jacob. Ren checks on him and asks if he's injured, discovering that Niamh had already cured it. Ren uses her psionic powers to help him rest.

Bri goes to sleep out, but Dax tells her she should sleep inside to benefit from the Alarm spell he cast. She goes to sleep inside, but around 2-3 am, goes outside again.

Ren confronts Dax about Bri kissing him - despite Bri having disclosed that in confidence. She learns that Dax has also, by now, kissed Niamh. Dax lets her in on how shocked he was himself, and that the banging of the headboards was just Dax and Niamh messing with Bri and Ren. Ren threatens Dax to be careful. Dax says he'll figure himself out and talk to Bri.

Niamh and Sana get up early. Niamh wakes Dax to ask if they're continuing their "flirty ruse". When he begs for coffee first, she kisses him on the cheek and tells him "never!". Niamh goes outside to wake Bri, who is very fast asleep. As Bri rolls over, Niamh notices some fungal strands retreating back into her chest. They disappear before Bri, who is apparently unaware of these, can see them. Though her nighty is laced with holes. Niamh panics internally, while Bri is still very sleepy, and goes to find Ren.

She shares the news and they discuss what might be going on. Niamh asks Ren to keep an eye on Bri, without telling her, and says how she doesn't know if she can trust Bri right now. Dax spends the entire morning with Sana, helping out where necessary, to avoid the others.

After a few false starts (bear - turtle - fox), Bri wildshapes into a riding horse and takes Jacob to stay with Bron, a distant neighbour, until the undead threat has been traced and dealt with. She forgets to actually tell the group that this is her intent, but Ren is able to communicate telepathically with her and clears it up.

Once Bri has left, Niamh discloses about the strands to the rest of the group. They debate how to find out more about what's going on, no-one knows much about plants. Sana proposes finding a mage, Ren suggests asking [[Naiadra of the Hidden Glade]]. They agree to keep an eye on her. Sana brings up that she has shown no ill-will so far and she hasn't attempted to hurt anyone. They discuss how the goodberries appear to do no harm. Niamh still doesn't trust her and cautions Dax to avoid her. Ren reminds them all, with Dax's agreement, that she is still Bri.

Dax brings up how her attitudes and abilities have changed, for example when a field of mushrooms appeared (ooc, due to Bri's entangle spell). Especially for a cleric of Tomealina, a goddess of knowledge. Niamh states her distrust again; Dax and Sana agree with caution, but express concern for Bri over themselves and how Bri has been trustworthy. Niamh again shows her distrust, saying how Bri ran forwards into danger. Sana talks about the intrinsic kindness Bri demonstrated by trying to save people by doing that.

They discuss Ren's shapechanging into an orc briefly, while Dax talks about all the wild and wondrous things in the world. Dax's final point is that "Bri is Bri. She may be in danger, we need to protect them and find out what this is". Sana pulls him aside and suggests asking the Syndicate for information on Bri. They agree to split any debt thus incurred.

The group hit the road, following the tracks made by the undead. They notice that the tracks seem to converge from several directions. After a little while, they lose the tracks, but with Fieran's aid, eventually find an overgrown cemetery nearby where a good proportion of them originate. Fieran scouts the terrain while Huxley stays aloft and keeps an eye out for Bri.

Meanwhile, Bri drops Jacob off at Bron's. Bron is gruff at first but quickly turns sympathetic on hearing the news about the Branwells. She then races back to meet the others.

Next: [[E03 Unexpected Encounters]]