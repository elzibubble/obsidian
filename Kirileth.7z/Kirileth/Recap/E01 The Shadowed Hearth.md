---
tag: recap
---
Prev: [[E00 Prequels]]

Absent: Ren

We begin on the road, a day and a half away from checking on [[The Branwells]]. Niamh noticed a bear just off the road, which might come at the cart. After a brief discussion of tactics, some inevitable flirting and some roar practice, Bri used Thaumaturgy and Speak with Animals to attempt to scare it away, yelling with a big roar "Go away bear, we're terribly scary!". This did not work. In fact, it summoned another bear from the nearby cave. Roll initiative!

Niamh starts off proceedings with a Faerie Fire, surrounding one bear with an unearthly sapphire glow. Dax casts Dragon's Breath on Huxley (his owl), who breathes fire at a tree in an attempt to scare off the bears, but they are not discouraged. Sana tried to scare the bears off again by firing an eldritch blast at a tree and raising her arms in the air, and got bitten for her trouble. Angered by this, she let loose a Hellish Rebuke. Bri roars, drawing on her divine powers to Command both bears to flee. Both ran back into the cave, Dax instructing Huxley to breathe fire to (temporarily) seal them in and allow us to make our escape.

Sana, having been bitten, asked Bri for some Goodberries to heal up. Dax is still suspicious of them. We agree to make camp, with Sana on first watch, Bri on second, Dax on third and Niamh on fourth.

When Bri wakes Dax for his watch, she seems to have mysteriously acquired lipstick that wasn't there earlier. Dax commends her on ending the fight with the bears peacefully - admittedly after having first incited them to attack. Bri talks about how quiet it is and how lovely the stars and moon are looking, but Dax shuts her down and sends her to bed. After she's asleep, he does tuck her into her bedroll a little more however, and he's noticeably distracted throughout his watch.

He then wakes a sleepy Niamh. Dax mentions he's slept rough plenty of times before. Harking back to their conversation at the house and Niamh's grappling with necessary violence, Dax laments how life on the road can numb a soul. He advises Niamh to retain her sense of morality and asks her to keep him from being too callous. Niamh agrees, mentioning a desire to make her mother proud.

Dax then discusses his pride and joy in combat, a wildness that comes out in him, and says that he sees the same in Bri - more than he's comfortable with. He asks Niamh to watch them both. Niamh regrets how her first impulse with the bears was aggressive, to limn them to receive blows, and agrees to mutually mind each member of the company. They embrace in a friendly manner and tell each other they are each "good people".

Dax discloses that their flirtation may have affected Bri, and that she surprised him with a kiss when he tried to mollify her, much to Niamh's surprise. Niamh thinks Bri is "so innocent". They flirt. Niamh realises why Dax has been a touch strange and distant the last few days. Dax is still trying to figure out his own emotions. Niamh jokes about them fooling around, before laughing it off. In response, Dax very gently leans forward and kisses her on the cheek. Niamh expresses her foremost desire for friendship before any relationship develops. Dax says she has that, and kisses her twice more, once very very lightly on the lips and then once on the forehead.

Dawn arrives with a fresh spring warmth. Niamh cooks breakfast. Fieran is a picky eater. Sana discloses she tends to burn food badly and is removed from the cooking rota. Dax sits next to Bri for breakfast and asks her for a Goodberry, who gives him an unidentified fruit (a kiwi). Bri thanks him for the trust. They chat a little more, and Bri scoots over towards him a little bit on their seat. They then finish their breakfasts companionably.

---

As we approach the homestead, Niamh sends Fieran up to scout. A humanoid shape stumbles towards us, patches of red on his ripped villager's tunic from a wound. She describes him then recognises him as Jacob, causing Sana and Bri to rush forward as Dax and Niamh come out of their familiars' senses and mind the cart.

Bri greets Jacob and gives him several Goodberries to eat which he does, telling them his family has been attacked. Bri immediately runs forward, calling for Sana to join her as Sana gives Jacob a quick Medicine check. Niamh casts Cure Wounds on him through Fieran and gets him into the wagon. Jacob tells Niamh his family were attacked by monsters - dead monsters, that look like corpses and smelled awful.

Niamh gets a nat 20 on her medicine check to determine if Jacob's bite wound is infected. It is and she casts Lesser Restoration, causing some black ichor to ooze out, then sends Fieran off to recall Bri and Sana. However, concerned he will make them too late to save the Branwells, Bri pushes Fieran aside and keeps running. Sana proposes she stealth ahead, but Bri keeps running. Niamh frets over her safety, and tells Dax that they'll need to talk with her about running ahead.

When Bri gets to the homestead, she runs up the stairs, almost slipping on the blood coating them and shouting out to warn Sana. She discovers a body in the lounge, with a large pool of blood around it, greatly wounded and lying perfectly still.

Dax puts up a mirror image and him and Niamh abandon the cart to Jacob's care and run forward. When they reach the homestead, they hear the cellar hatch rattling before it bursts open and two zombies come out. Fighting ensues as another zombie and a skeleton come in from the back of the house to attack Bri. Blows are exchanged, Sana summons the Arms of Hadar to immolate the zombies at the front as Cordelia helps Bri maneuver to escape her attackers and join the rest.

None of the undead have yet been taken out when a large, humanoid mass of corpses emerges from around the corner of the house - a tomb titan! The team continue to press their attacks and the walking dead are taken out without major injury.

Immediately Niamh turns to Bri, grabs her shoulders, stares her in the eye, checks if she's OK and then begins to scold her for running ahead. Bri attempts to defend herself, talking about how people could have died before they got there if she'd waited and how it all worked out. Niamh forces her to sit down and continues telling her off for being dumb and rushing in, potentially endangering the group in having to rescue her. Bri reluctantly submits after a moment's resistance, then sticks out her tongue as soon as her back is turned. Dax notices this, catches Bri's eye but just winks at her. Talking to her, he doesn't take a side, saying each one has a point. Sana mentions how she tried to make Bri stay back while she scouted, alone, instead. Dax attempts to rebalance the argument, saying how it worked out well, and to refocus the group on searching for survivors. Niamh commands Bri to go in last, which Bri ignores.

They find the mother of the family, Cat, also dead in the cellar. Jacob breaks down and Sana sits with him as he cries.

Next: [[E02 The Darkness Beneath]]