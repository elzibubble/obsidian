---
tag: recap
---
Prequel 1: We started in [[Little Meldon]]. A little girl ([[Aria Hargrave]]) needed her brother ([[Kaelan Hargrave|Kaelan]]) rescued from a cave, turns out the cave had cultists in it arguing over whether to sacrifice the kid. [[Dax|Dax]] slew one with a magic missile and [[Bri|Bri]] terrified the other two into surrendering. We obtained a book entitled approximately "[[Dark Magic for Dummies]]".

Prequel 2: When we got back to town, orcs had attacked, everything was on fire. The Holy Library, in particular, burned to ashes but we rescued everyone close to us. In shock after this, [[Bri|Bri]] went for a little walk and got hit by a meteorite containing [[Cordelia]], her wildfire spirit. This infected her and she began to manifest druidic powers, which confused her for some time.

Prequel 3-4: We set out towards [[Aerilon]]. [[Bri|Bri]] observed [[Dax|Dax]] training, shirtless, with his whip, trying to remember the Bladesong. Along the way we were betrayed by our guide (Ciaran) to more cultists. [[Ren]] killed one with a Chaos Bolt and [[Bri|Bri]] showed off a new aggressive streak. A nymph ([[Naiadra of the Hidden Glade]]) and her tree warriors finished the fight, gave us food and rest and sent us on our way. With a strict promise not to reveal her glade.

Prequel 5: The captain of the guard ([[Captain Darien]]) in [[Aerilon]] was very gracious and put up all our refugees. Most at the [[Silver Star]] (temple of Aradin), but we few at the [[Singing Harp]] inn. Our first night there turned into quite the party as [[Niamh|Niamh]] slid into the performance of [[Kari the bard]], everyone got involved.

Prequel 6: We went to see [[King Eadric Lioncrest]] in the morning and reported the raid. [[Bri|Bri]] wanted to investigate the cultists, feeling something much darker and more competent could be hidden from view, but we lacked leads and were instead directed towards [[Gorn the blacksmith]] by [[Captain Darien]]. [[Gorn the blacksmith|Gorn]] expressed his frustration at missing metal shipments, particularly with orcs about causing an increase in demand for weaponry.

Prequel 7: [[Alfie]] from the [[Syndicate]], who [[Dax|Dax]] used to work for, approached him about a merchant who wasn't paying his debt. [[Sana]] was introduced to the group as additional muscle. We scoped the place out thoroughly and [[Ren]] broke his window as a distraction, but eventually convinced the man to pay up without any bloodshed. Sana decided to join the group.

Prequel 8-10: We went out and found a slaughtered caravan next to a blocked road. We attacked a bandit camp, killing them all, then we waited for some more to arrive and killed them too. We retrieved the missing ore and tools and were rewarded, we should also get a deal on future purchases. We found a note from a "CR", this turned out to be Caleb, a rival blacksmith who we sent the guard to arrest.

Prequel 11: The gang got back to [[Aerilon]] and before they even entered the gates, heard from the guards that [[Westvale]] had also been attacked by [[Orc raids||orcs]]. We reported to [[Captain Darien]] who explained that due to the new influx of refugees, it was impractical to put us up at the [[Singing Harp]] any longer. However, there was an abandoned house we could have, score! On our way out, [[Captain Darien]] asked us to speak to [[The Branwells|Rynne Branwell]]. She wanted us to check on her family, who lived at a small homestead east of the city.

Bri spent the day cleaning out the house. Niamh grabbed Dax by his lapels and dragged him into one of the bedrooms for a heartfelt moment of doubt about whether she could handle the adventuring life and the murder and mayhem it entailed. To cover for this, Dax spent some time thumping the headboard against the wall.

Bri was very quiet at supper. Prodded by the others as to why, she didn't answer, but pushed over the edge by Ren telepathically asking if it was the lack of help cleaning that was bothering her, she stormed out. She was intending to go to the woods to calm down, but Dax went after her and caught up with her. He sweet-talked her down from her mood and did such a good job that Bri's heart pounding, she took a chance and kissed him then and there. After returning Bri to the house, Dax went out drinking, all night, to think.

Next: [[E01 The Shadowed Hearth]]