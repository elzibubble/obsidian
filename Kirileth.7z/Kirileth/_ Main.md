---
tag: nograph
---
[[Currently in Kirileth]]
[[E00 Prequels]]


# Plotlines

[[Dark Magic for Dummies]]
[[Orc raids]]
[[Blacksmith supplies]]


# Key locations

[[Aerilon]]


# Key NPCs

[[King Eadric Lioncrest]]
