We found some wannabe cultists arguing over whether to sacrifice [[Kaelan Hargrave]].

Ciaran, our guide towards Aerilon, betrayed us to some cultists who all died, at our hands and [[Naiadra of the Hidden Glade]].

[[Niamh|Niamh]] found a book in the library about Karnos, the god of blood and slaughter: https://www.worldanvil.com/w/kirileth-dmstretch/a/karnos-person