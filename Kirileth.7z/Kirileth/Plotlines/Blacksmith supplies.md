[[Gorn the blacksmith]] asked us to look into some missing blacksmith supplies. We went out and found a slaughtered caravan next to a blocked road. We attacked a bandit camp, killing them all, then we waited for some more to arrive and killed them too.

We retrieved the missing ore and tools and were rewarded, we should also get a deal on future purchases.

We found a note from a "CR", this turned out to be Caleb, a rival blacksmith who we sent the guard to arrest.