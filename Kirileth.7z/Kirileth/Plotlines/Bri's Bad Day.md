[[Bri]] was hit by a meteorite (well, a piece from an airburst) immediately after the refugees from [[Little Meldon]] were brought to the cave just outside town.

The wound was easily healed by Bri using her existing Divine powers, but a subcutaneous web of green remained. Consequently, Bri began to manifest druidic abilities and eventually summoned a wildfire spirit. This was interspersed with some strange swings in personality, beginning with some euphoria and dissociation on the way to [[Aerilon]] which gave way to a predatory fierceness when violence became necessary.

She began to manufacture Goodberries every day, attempting to pass them around to anyone hungry or wounded, but received considerable suspicion from [[Dax|Dax]], [[Niamh|Niamh]] and [[Ren]].

At the bandit camp during [[Blacksmith supplies]], Bri killed for the first time and seemed unbothered by it.

Arriving at the [[Branwell massacre]], Bri rushed ahead to try and save the Branwells. She was relatively unaffected by the scene of carnage and worked with [[Cordelia]] to help take out the Tomb Titan.

When we reached the graveyard, Bri chose to deconstruct the pillar of bones we found, reconsecrate them and place them under the earth in the graveyard. During the ensuing ambush by some necrotic horror, Bri was badly bitten and fell unconscious. Afterwards, Bri seemed almost drunk, with lowered inhibitions and a slur in her speech.

When interrogated by Niamh, Bri expressed how it was sometimes easier to "sit back" and let Cordelia take control.