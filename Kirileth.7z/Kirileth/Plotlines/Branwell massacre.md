[[The Branwells|Rynne Branwell]] asked us to check on her family, who lived at a small homestead four days east of [[Aerilon]].

We were attacked by some orcs on wargs en-route but defeated them with few problems.

When we got there, Jacob ran out to meet us, telling us the homestead was under attack. [[Bri|Bri]] ran in, with [[Sana|Sana]] on her heels, to try and rescue them while [[Niamh|Niamh]] and [[Dax|Dax]] brought up the cart.