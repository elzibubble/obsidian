Rules [[Aerilon]] and surrounds. Lives in [[Castle Aerilon]].

Described as similar to Ned Stark in outlook.