Runs the [[Ironclaw Smithy]] in [[Aerilon]].

Should give us a discount due to plotline [[Blacksmith supplies]].