Captain of the [[Aerilon]] guard.

Has deputised us, allowing us to go on missions for him and access the [[Castle Aerilon]] library.