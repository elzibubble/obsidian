Rynne Branwell is the mother of Sam Branwell.

Sam and Cat Branwell were married, with one teenage child, Jacob.

Jacob has been safely reunited with his grandmother.

See the [[Branwell massacre]].