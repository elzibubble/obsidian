As far as anyone in town knows, Ren is the human daughter of the local potter and his wife (Soren and Orla Doyle). But the household dynamic is clearly quite strained, especially between the mother and daughter (as any close neighbors can attest). Ren is rarely seen, except for running errands. 

A few years ago, the potter's wife became quite ill, and despite many attempts to try new healers and new medicines, she never recovered. For the particularly nosy among the neighbors, it is curious how the potter could afford so much in the way of healers / medicines / etc. Especially since the daughter never took up learning his trade. For the last year or so now, since the wife's passing, it's been just the potter and his daughter, and despite the fact that in his grief the potter is working less and less, somehow the household is staying afloat. 

Has telepathy and a tendency towards verbal diarrhoea when flustered or excited.

Telepathic, possibly asexual. Good friends with Bri.