Daxillium Bramblethorn, Dax to almost everyone, is the child of an elf maid dallying with a human soldier. His mother died in childbirth and his father never stuck around to see what happened to him. He was raised by his grandfather, a well-to-do elven mage.

Dax from a young age rebelled against his grandfather, frequently running away and getting into mischief. Despite their rough relationship he did learn a bit of mystic lore from him, although he took it in a more martial direction than the scholarly old elf.

After a particularly nasty fight he was sent off to live with a distant friend of his grandfathers in the far village of Little Meldon. He currently resides with the woman known in the town as Old Helga, or to the kids of the town as "Run! Its that crazy woman with the sling!". Helga rarely leaves her home and almost never seems to notice that Dax is living in her spare bedroom. He is known to hang around the tavern quite often. Always quick with a jest and happy to buy a round of drinks.

Previously affiliated with the [[Syndicate]].

[[Bri]] kissed him but has been let down gently since.

Flirts outrageously with [[Niamh]] and has twice kissed her.

Dax has not come from a great background and is trying to make up for something from his past.