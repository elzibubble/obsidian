Brother of [[Aria Hargrave]]. From [[Little Meldon]].

We rescued him from cultists, right in prequel 1.