[[Dax]] and [[Sana]] used to work for them but have cut ties.

[[Diego]], top man.
[[Alfie]], sergeant?

We intimidated a merchant into paying his debt for them, [[Sana|Sana]] was sent with us to aid us and joined our band thereafter.